#pragma once
#include "Type.h"

class Color
{
public:
	void setColor(short text);
};
