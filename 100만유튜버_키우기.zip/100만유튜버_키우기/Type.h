#pragma once

#include<iostream>
#include<string>
#include<vector>
#include<random>
#include<stdlib.h>
#include<windows.h>

using namespace std;